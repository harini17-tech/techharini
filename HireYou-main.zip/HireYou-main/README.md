Helloo yaar ! Hope you understand the word "HireYou" which means preparing yourself to get hired in our dream roles. In my project, I have made a complete roadmap to major roles in Artificial Intelligence and Data science such as AI Engineer, Data Analyst, ML Engineer, Data Scientist and Prompt Engineer. 

HireYou consists of all the syllabus required to cover up to get placed for the respective roles. There are 500 questions in each role covering all the topics in the respective roles and there is a mock test of 100 questions which can test your knowledge by completing all these 600 questions for a role.

They are separated as 10 levels consisting of all the basic to deep knowledges in each syllabus which helps the user to gain knowledge of all the topics.

Yeah, Now the user will be ready for the role but to get into the job, he/she needs to pass the prior levels like aptitude rounds and group discussions. 

Ofcourse, HireYou trains you for the aptitude session too ! Nice nah ! There are every topics including both Quantitative and logical reasoning which also consists of 600 questions. So that, My user will be perfect in answering aptitude questions.

Next comes the main round "HR INTERVIEW" which makes my user to learn how to answer the tricky questions by the HRs in a smarter way and test his performance , validate and guide him throught out all the general questions asked in an interview. 

Buddy Yeah You got that Right ! HireYou is to train the users in all means including aptitudes, syllabus, technical knowledge, listening and speaking skills. 

Now, You can just open "index.html" and start using my website and I hope you all will really get benefited from this !
